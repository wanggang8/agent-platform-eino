# Phase 8 Batch B Live Smoke Blocked

日期：2026-07-06
方案：Batch B “我的范围”真实 live smoke
状态：Blocked

## Command

```bash
bash scripts/eino_workbench_server_smoke.sh --scenario fobrain-batch-b --config configs/eino-workbench.local.yaml
```

## Report

本地 ignored 报告：

```text
test-results/eino-workbench-fobrain-batch-b-live-report.json
```

报告已通过：

```bash
node scripts/eino_workbench_report_validate.mjs \
  --schema docs/schemas/fobrain/batch_b_live_report.v1.schema.json \
  --report test-results/eino-workbench-fobrain-batch-b-live-report.json
```

## Result Summary

- `status=blocked`
- `failure_category=missing_current_user_scope`
- `tool.fobrain.my_department_assets`：`blocked`，`missing_current_user_scope`
- `tool.fobrain.my_department_vulnerabilities`：`blocked`，`missing_current_user_scope`
- 其余四个“我的范围”工具返回空结果，均为 `blocked`，`empty_result`
- 报告不包含 token、auth header、credential ref、raw provider payload、当前用户值、部门值或 `safe_summary`

## Current User Scope Probe

本地只读探测只输出字段形态，不记录字段值：

- 当前私有部署命中 `/api/user`；`/api/v1/user` 不作为当前可用路径。
- 当前用户响应没有 `department`、`department_name`、`departments`、`department_names`、`department_id` 或 `department_ids`。
- `staff_ids` 存在但为 `null`，不能作为人员台账绑定。
- `rule_info` 只包含 `range` 和 `rule_info`，属于展示配置，不能作为部门或 owner 范围。
- `test-results/eino-workbench-fobrain-sample-discovery-report.json` 中 `staff_seed` 与 `department_seed` 均为 `path_unavailable`，无法通过人员台账或部门接口补齐当前用户部门。
- discovery 找到的稳定 owner/department/IP 样本只证明 Batch D 参数化查询可验收，不能替代当前用户范围。

## Decision

当前真实环境不能声明 Batch B live pass。原因不是 smoke 基础设施缺失，而是当前用户上下文不足以派生本部门范围，且当前用户范围查询返回空结果。当前证据不支持用任意 discovery 样本伪装“我的范围”。后续需要使用绑定真实 staff/department 且拥有可见数据的账号重跑，或由产品明确超级管理员/无人员绑定账号的“我的范围”语义。

## Explicit Non-Claims

- 不声明 Batch B live pass。
- 不声明 Batch B Workbench 视觉通过。
- 不声明 Batch B Action API 同源 smoke 通过。
- 不声明 Fobrain 24/24 只读恢复完成。
